import React, { createContext, useContext, useState, ReactNode } from 'react';
import { NewsArticle, latestNews as initialLatestNews, economyNews as initialEconomyNews, politicsNews as initialPoliticsNews, societyNews as initialSocietyNews, technologyNews as initialTechnologyNews, healthNews as initialHealthNews, popularNews as initialPopularNews } from '@/data/mockNews';

interface NewsContextType {
  latestNews: NewsArticle[];
  economyNews: NewsArticle[];
  politicsNews: NewsArticle[];
  societyNews: NewsArticle[];
  technologyNews: NewsArticle[];
  healthNews: NewsArticle[];
  popularNews: NewsArticle[];
  addNews: (news: Omit<NewsArticle, 'id'>) => void;
}

const NewsContext = createContext<NewsContextType | undefined>(undefined);

export const useNews = () => {
  const context = useContext(NewsContext);
  if (!context) {
    throw new Error('useNews must be used within a NewsProvider');
  }
  return context;
};

interface NewsProviderProps {
  children: ReactNode;
}

export const NewsProvider: React.FC<NewsProviderProps> = ({ children }) => {
  const [latestNews, setLatestNews] = useState(initialLatestNews);
  const [economyNews, setEconomyNews] = useState(initialEconomyNews);
  const [politicsNews, setPoliticsNews] = useState(initialPoliticsNews);
  const [societyNews, setSocietyNews] = useState(initialSocietyNews);
  const [technologyNews, setTechnologyNews] = useState(initialTechnologyNews);
  const [healthNews, setHealthNews] = useState(initialHealthNews);
  const [popularNews, setPopularNews] = useState(initialPopularNews);

  const addNews = (news: Omit<NewsArticle, 'id'>) => {
    const newId = Date.now().toString(); // Simple ID generation
    const newArticle: NewsArticle = { ...news, id: newId };

    // Add to latestNews
    setLatestNews(prev => [newArticle, ...prev]);

    // Add to category-specific array
    switch (news.categorySlug) {
      case 'economia':
        setEconomyNews(prev => [newArticle, ...prev]);
        break;
      case 'politica':
        setPoliticsNews(prev => [newArticle, ...prev]);
        break;
      case 'sociedade':
        setSocietyNews(prev => [newArticle, ...prev]);
        break;
      case 'tecnologia':
        setTechnologyNews(prev => [newArticle, ...prev]);
        break;
      case 'saude':
        setHealthNews(prev => [newArticle, ...prev]);
        break;
      default:
        break;
    }

    // Optionally add to popularNews
    setPopularNews(prev => [newArticle, ...prev.slice(0, 4)]);
  };

  return (
    <NewsContext.Provider value={{
      latestNews,
      economyNews,
      politicsNews,
      societyNews,
      technologyNews,
      healthNews,
      popularNews,
      addNews
    }}>
      {children}
    </NewsContext.Provider>
  );
};