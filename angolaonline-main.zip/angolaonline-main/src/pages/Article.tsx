import { useParams, Link } from 'react-router-dom';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Sidebar } from '@/components/Sidebar';
import { NewsCard } from '@/components/NewsCard';
import { ChevronLeft, Share2, Facebook, Twitter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNews } from '@/contexts/NewsContext';
import { featuredNews } from '@/data/mockNews';

const Article = () => {
  const { id } = useParams<{ id: string }>();
  const { latestNews, popularNews } = useNews();

  const getArticleById = (id: string) => {
    const allNews = [featuredNews, ...latestNews];
    return allNews.find((article) => article.id === id) || featuredNews;
  };

  const article = getArticleById(id || '1');
  const article = getArticleById(id || '1');
  const relatedNews = latestNews.filter((n) => n.id !== article.id).slice(0, 3);

  const categoryColors: Record<string, string> = {
    economia: 'category-economia',
    politica: 'category-politica',
    sociedade: 'category-sociedade',
    ambiente: 'category-ambiente',
    industria: 'category-industria',
    saude: 'category-saude',
    tecnologia: 'category-tecnologia',
    cultura: 'category-cultura',
    educacao: 'category-educacao',
  };

  const categoryClass = categoryColors[article.categorySlug] || 'category-economia';

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1">
        <div className="container py-8">
          {/* Breadcrumb */}
          <nav className="mb-6">
            <Link
              to="/"
              className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary transition-colors"
            >
              <ChevronLeft className="h-4 w-4" />
              Voltar à página inicial
            </Link>
          </nav>

          <div className="grid lg:grid-cols-[1fr_320px] gap-8">
            {/* Article Content */}
            <article className="bg-card rounded-lg border border-border overflow-hidden">
              {/* Article Header */}
              <div className="p-6 md:p-10">
                <span className={`category-badge ${categoryClass}`}>
                  {article.category}
                </span>
                
                <h1 className="mt-4 text-2xl md:text-4xl font-bold text-balance leading-tight">
                  {article.title}
                </h1>

                <p className="mt-4 text-lg text-muted-foreground">
                  {article.excerpt}
                </p>

                <div className="mt-6 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                  <span className="font-medium text-foreground">{article.author}</span>
                  <span>•</span>
                  <time>{article.date}</time>
                </div>

                {/* Share buttons */}
                <div className="mt-6 flex items-center gap-2">
                  <span className="text-sm text-muted-foreground mr-2">Partilhar:</span>
                  <Button variant="outline" size="icon" className="h-9 w-9">
                    <Facebook className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-9 w-9">
                    <Twitter className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon" className="h-9 w-9">
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              {/* Featured Image */}
              <div className="aspect-[16/9] overflow-hidden">
                <img
                  src={article.image}
                  alt={article.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Article Body */}
              <div className="p-6 md:p-10 prose-article">
                <p className="text-lg leading-relaxed mb-6">
                  A informação foi confirmada durante uma conferência de imprensa realizada esta manhã no Palácio Presidencial, onde altos funcionários do governo detalharam os termos do acordo histórico que promete transformar o panorama económico do país.
                </p>

                <p className="text-lg leading-relaxed mb-6">
                  "Este é um momento de grande importância para Angola e para o nosso futuro", declarou o porta-voz do governo, sublinhando que o acordo representa anos de negociações e uma visão estratégica para o desenvolvimento sustentável da nação.
                </p>

                <blockquote className="border-l-4 border-primary pl-6 my-8 italic text-lg text-muted-foreground">
                  "O investimento irá beneficiar directamente milhões de angolanos, criando postos de trabalho e impulsionando sectores estratégicos da economia."
                </blockquote>

                <p className="text-lg leading-relaxed mb-6">
                  O pacote de investimentos abrange múltiplos sectores, incluindo infraestruturas, energia renovável, tecnologia e agricultura. Especialistas económicos elogiaram a iniciativa, destacando o seu potencial para diversificar a economia nacional e reduzir a dependência do sector petrolífero.
                </p>

                <p className="text-lg leading-relaxed mb-6">
                  Os primeiros projectos deverão arrancar ainda no primeiro trimestre deste ano, com a expectativa de que os benefícios económicos comecem a ser sentidos pela população nos próximos meses. O governo comprometeu-se a divulgar relatórios trimestrais sobre o progresso das iniciativas.
                </p>

                <p className="text-lg leading-relaxed mb-6">
                  Representantes da comunidade empresarial manifestaram optimismo cauteloso, salientando a importância de garantir a transparência e a boa governação na implementação dos projectos. "É fundamental que estes investimentos se traduzam em benefícios reais para o povo angolano", afirmou o presidente da câmara de comércio.
                </p>

                <p className="text-lg leading-relaxed">
                  O acordo inclui ainda cláusulas que prevêem a transferência de conhecimento e tecnologia, bem como programas de formação para profissionais angolanos. Esta componente é vista como crucial para garantir a sustentabilidade dos projectos a longo prazo e para capacitar a força de trabalho nacional.
                </p>
              </div>

              {/* Tags */}
              <div className="px-6 md:px-10 pb-6 md:pb-10 border-t border-border pt-6">
                <div className="flex flex-wrap gap-2">
                  <span className="text-sm text-muted-foreground mr-2">Tags:</span>
                  {['Investimento', 'Economia', 'Governo', 'Desenvolvimento'].map((tag) => (
                    <Link
                      key={tag}
                      to={`/tag/${tag.toLowerCase()}`}
                      className="px-3 py-1 text-sm bg-muted rounded-full hover:bg-muted/80 transition-colors"
                    >
                      {tag}
                    </Link>
                  ))}
                </div>
              </div>
            </article>

            {/* Sidebar */}
            <div className="hidden lg:block">
              <Sidebar
                latestNews={latestNews.slice(0, 5)}
                popularNews={popularNews}
              />
            </div>
          </div>

          {/* Related Articles */}
          <section className="mt-12">
            <h2 className="text-xl md:text-2xl font-bold pb-2 border-b-4 border-primary mb-6">
              Artigos Relacionados
            </h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedNews.map((news) => (
                <NewsCard key={news.id} {...news} variant="default" />
              ))}
            </div>
          </section>
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Article;
