import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useNews } from '@/contexts/NewsContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';

const categories = [
  { name: 'Economia', slug: 'economia' },
  { name: 'Política', slug: 'politica' },
  { name: 'Sociedade', slug: 'sociedade' },
  { name: 'Ambiente', slug: 'ambiente' },
  { name: 'Indústria', slug: 'industria' },
  { name: 'Saúde', slug: 'saude' },
  { name: 'Tecnologia', slug: 'tecnologia' },
  { name: 'Educação', slug: 'educacao' },
  { name: 'Cultura', slug: 'cultura' },
];

const Admin = () => {
  const { isAuthenticated, logout } = useAuth();
  const { addNews } = useNews();
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    title: '',
    excerpt: '',
    content: '',
    category: '',
    categorySlug: '',
    image: '',
    author: 'AngolaOnline',
  });
  const [success, setSuccess] = useState('');

  if (!isAuthenticated) {
    navigate('/login');
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const selectedCategory = categories.find(cat => cat.slug === formData.categorySlug);
    if (!selectedCategory) return;

    const newNews = {
      title: formData.title,
      excerpt: formData.excerpt,
      content: formData.content,
      category: selectedCategory.name,
      categorySlug: formData.categorySlug,
      image: formData.image,
      date: new Date().toLocaleDateString('pt-PT'),
      author: formData.author,
    };

    addNews(newNews);
    setSuccess('Notícia adicionada com sucesso!');
    setFormData({
      title: '',
      excerpt: '',
      content: '',
      category: '',
      categorySlug: '',
      image: '',
      author: 'AngolaOnline',
    });
  };

  const handleCategoryChange = (value: string) => {
    const category = categories.find(cat => cat.slug === value);
    setFormData({
      ...formData,
      categorySlug: value,
      category: category ? category.name : '',
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container max-w-4xl">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold">Painel Administrativo</h1>
          <Button onClick={logout} variant="outline">
            Sair
          </Button>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Adicionar Nova Notícia</CardTitle>
            <CardDescription>
              Preencha os campos abaixo para adicionar uma nova notícia ao site.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="title">Título</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="excerpt">Resumo</Label>
                <Textarea
                  id="excerpt"
                  value={formData.excerpt}
                  onChange={(e) => setFormData({ ...formData, excerpt: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="content">Conteúdo Completo</Label>
                <Textarea
                  id="content"
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  rows={10}
                  required
                />
              </div>
              <div>
                <Label htmlFor="category">Categoria</Label>
                <Select onValueChange={handleCategoryChange} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma categoria" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((cat) => (
                      <SelectItem key={cat.slug} value={cat.slug}>
                        {cat.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="image">URL da Imagem</Label>
                <Input
                  id="image"
                  type="url"
                  value={formData.image}
                  onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                  required
                />
              </div>
              <div>
                <Label htmlFor="author">Autor</Label>
                <Input
                  id="author"
                  value={formData.author}
                  onChange={(e) => setFormData({ ...formData, author: e.target.value })}
                  required
                />
              </div>
              {success && (
                <Alert>
                  <AlertDescription>{success}</AlertDescription>
                </Alert>
              )}
              <Button type="submit" className="w-full">
                Adicionar Notícia
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Admin;